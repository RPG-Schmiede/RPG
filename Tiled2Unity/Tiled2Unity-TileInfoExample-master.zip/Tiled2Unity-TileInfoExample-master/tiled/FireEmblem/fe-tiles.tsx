<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tiles" tilewidth="16" tileheight="16" spacing="1" margin="1">
 <image source="fe-tiles.png" width="762" height="460"/>
 <tile id="0" probability="0.5"/>
</tileset>
