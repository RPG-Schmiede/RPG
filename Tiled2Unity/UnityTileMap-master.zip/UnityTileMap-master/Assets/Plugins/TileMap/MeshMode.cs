﻿namespace UnityTileMap
{
    public enum MeshMode
    {
        SingleQuad,
        QuadGrid
    }
}
