﻿public enum TileType
{
    Empty,
    Wall,
    Floor,
    StairsUp,
    StairsDown
}
